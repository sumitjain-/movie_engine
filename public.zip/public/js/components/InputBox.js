var InputBox = React.createClass({
	render: function () {
		return (
			<form>
				
			</form>
		)
	}
});